import { createFileRoute, redirect } from '@tanstack/react-router';
export const Route = createFileRoute('/index.html')({ beforeLoad: () => { throw redirect({ to: '/' }); } });
